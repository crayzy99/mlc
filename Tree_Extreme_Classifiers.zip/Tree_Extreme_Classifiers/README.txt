Please make sure that you read and agree to the terms of license (License.pdf) and copyright (liblinear_COPYRIGHT) before using this software.

For instructions on using a specific algorithm (among FastXML/PfastreXML/SwiftXML/Parabel), please refer to README.txt in the respective folder.
Toy example of FastXML/PfastreXML/SwiftXML/Parabel over EUR-Lex dataset is also included in the respective folders as "sample_run.sh"/"sample_run.bat"
